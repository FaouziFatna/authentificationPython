<script>
        $(document).ready(function() {
            $("#myBtn").click(function() {
                $("#myModal").modal({
                    show: true
                });
            });
            $("#myBtn2").click(function() {
                $("#myModal2").modal({
                    show: false
                });
            });
        });
    </script>