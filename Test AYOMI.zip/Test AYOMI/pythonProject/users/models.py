from django.db import models

# Create your models here.
class Users(models.Model):
    nom=models.CharField(max_length=200,null=True)
    adress=models.CharField(max_length=1000,null=True)
    email= models.EmailField(max_length=254, null=True)
    passeword=models.CharField(max_length=20,null=True)

    def __str__(self):
        return self.nom