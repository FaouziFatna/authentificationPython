from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login
from .forms import CreerUtilisateur, UserUpdateForm
from django.contrib import  messages
from django.contrib.auth.decorators import login_required



# Create your views here.
def inscription(request):
    form = CreerUtilisateur()
    if request.method == 'POST':
        form = CreerUtilisateur(request.POST)
        if form.is_valid():
            form.save()
            user=form.cleaned_data.get('username')
            messages.success(request,'Compte Crée avec Succès pour ' + user)
            return redirect('login')
    context = {'form': form}
    return render(request, 'users/inscription.html', context)


def connect(request):
    context = {}
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('accueil')
        else:
            messages.info(request,"il y a une erreur dans le nom d'utilisateur et/ou  mot de passe")
    return render(request, 'users/authentification.html')

@login_required
def home(request):
    if request.method == 'POST':
        u_form = UserUpdateForm(request.POST, instance=request.user)
        if u_form.is_valid():
            u_form.save()
            messages.success(request, f'Your account has been updated!')
    else:
        u_form = UserUpdateForm(instance=request.user)
    context = {'u_form': u_form}
    return render(request, 'users/home.html', context)
