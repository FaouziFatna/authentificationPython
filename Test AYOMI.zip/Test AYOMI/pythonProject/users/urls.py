from django.urls import path, include
from . import views
urlpatterns = [
    path('',views.inscription, name="inscription"),
    path('login',views.connect, name="login"),
    path('accueil',views.home, name="accueil"),
]

